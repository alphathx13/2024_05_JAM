package com.koreaIT.JAM.util;

import java.time.LocalDateTime;

public class Util {
	public static LocalDateTime now() {
		return LocalDateTime.now();
	}
}